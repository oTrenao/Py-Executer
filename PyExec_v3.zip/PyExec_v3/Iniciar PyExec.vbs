' ============================================================
'  Launcher do Py Executer Ultimate v3.0
'  Abre o app SEM janela de console (usa pythonw, oculto).
' ============================================================
Option Explicit

Dim shell, fso, here, pyw, target

Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")

' Pasta onde este .vbs esta
here = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = here

' Preferir o pythonw do ambiente isolado (.appenv); senao, o pythonw global
pyw = here & "\.appenv\Scripts\pythonw.exe"
If Not fso.FileExists(pyw) Then
    pyw = "pythonw"
End If

target = """" & pyw & """ """ & here & "\main.py"""

' Run(comando, estilo_janela=0 oculto, esperar=False)
shell.Run target, 0, False

Set shell = Nothing
Set fso = Nothing
