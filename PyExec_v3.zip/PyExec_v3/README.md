# Py Executer Ultimate — v3.0 (CustomTkinter)

Reescrita do núcleo da ferramenta, saindo do **HTA/JScript+ActiveX** para **Python + CustomTkinter**.
Esta entrega é a **fundação**: arquitetura modular + aba **Executar** 100% funcional com
streaming de saída em tempo real. As abas Builder/Tools/Sistema aparecem como
placeholders e serão portadas nas próximas fases.

## Como instalar e abrir

**1. Instalar** (cria um ambiente isolado `.appenv` e baixa as dependências):

```
install.bat
```

**2. Abrir sem janela de console** (duplo-clique):

```
Iniciar PyExec.vbs
```

**3. Abrir em modo depuração** (console visível, para ver erros):

```
Iniciar PyExec (debug).bat
```

Alternativa manual: `pip install -r requirements.txt` e `python main.py`.
Requer Python 3.10+ (no Windows o `tkinter` já vem junto com o Python).

## Por que isto é melhor que o HTA

O HTA executava qualquer coisa gerando um `.bat`, redirecionando para um arquivo de
log e fazendo *polling* a cada 500 ms — adivinhando o término por uma substring.
Aqui o núcleo usa `subprocess.Popen` direto, então os três problemas de
estabilidade que remendamos na v2.3/v2.4 somem **na raiz**:

| Antes (HTA) | Agora (v3.0) |
|---|---|
| Término por substring `[DONE]`/`[EXIT]` | `proc.returncode` real |
| `taskkill /IM python.exe` (matava todo Python) | encerra só o PID desta execução e seus filhos |
| Imports por `indexOf` (comentário/string viravam import) | parser via `ast`, exato |
| Lista fixa de stdlib | `sys.stdlib_module_names` do próprio interpretador |
| Ler log inteiro a cada 500 ms | fila thread-safe, linha a linha |

## Estrutura

```
PyExec_v3/
├── main.py                 # ponto de entrada (python main.py)
├── requirements.txt
└── pyexec/
    ├── theme.py            # paleta "Design System V16" (cores/fontes)
    ├── app.py              # janela principal: monta tudo + lógica
    ├── core/               # SEM UI — testável isoladamente
    │   ├── imports.py      # análise de imports via ast
    │   ├── pyenv.py        # detecção de Python e venv
    │   └── runner.py       # ProcessRunner: streaming + PID + stop preciso
    └── ui/
        ├── console.py      # console inferior + status colorido
        └── run_tab.py      # aba Executar
```

A separação `core` / `ui` é o ponto central da v3.0: a lógica não depende mais do
DOM (como no HTA). O `core` foi testado de forma automatizada, sem abrir janela.

## O que já funciona

- Explorador de arquivos `.py` + escolher pasta de trabalho.
- Detecção de interpretadores Python (caminhos comuns, `%LocalAppData%`, `py -0p`)
  e de venv local (`venv`/`.venv`/`env`).
- Indicador de ambiente (venv vs global), criar venv, reparar pip.
- **Executar**: streaming ao vivo, status ✓/✗ por código de saída, **Parar** preciso,
  modo interativo, verificar/instalar dependências (via `ast`), salvar log.
- **Builder**: PyInstaller e Nuitka, onefile/onedir/accelerated, ícone (converte
  png/jpg→ico), collect/exclude com scan, UPX, PyArmor, opções avançadas do Nuitka
  (output dir, progresso/memória, LTO, MSVC, include-data-dir), **perfis de build**,
  **Ver Comando** (preview sem executar).
- **Tools**: Pylint, Ruff, Black, Mypy, Bandit, Pip-Audit, Pytest, Pip Freeze;
  geração de `requirements.txt` (scan/freeze), ver/atualizar desatualizadas.
- **Sistema**: limpar lixo de build, salvar configuração, exportar log, pip manual.
- **Persistência**: opções salvas em `pyexec_config.json` ao fechar; perfis em
  `pyexec_profile_<nome>.json`.

## Próximas fases (v3.0+)

- **Build limpo** (venv temporária) orquestrado em Python.
- Gerenciador de venvs completo, empacotamento automático.
- Integração com IA (explicar erros de build, sugerir flags).
- Publicação no GitHub / assinatura de código.

## Observação sobre teste

O `core` (imports, runner, pyenv) foi validado com testes automatizados. A camada
gráfica precisa de um ambiente com display para ser vista — rode `python main.py`
no seu Windows para conferir visualmente.
