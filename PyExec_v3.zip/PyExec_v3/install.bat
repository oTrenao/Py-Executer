@echo off
title Py Executer Ultimate v3.0 - Instalacao
cd /d "%~dp0"
echo ==================================================
echo    Py Executer Ultimate v3.0  -  Instalacao
echo ==================================================
echo.

REM --- 1) Localizar Python ---
set "PYEXE="
where py >nul 2>&1 && set "PYEXE=py -3"
if not defined PYEXE (
    where python >nul 2>&1 && set "PYEXE=python"
)
if not defined PYEXE (
    echo [ERRO] Python nao foi encontrado no PATH.
    echo.
    echo Instale o Python 3.10 ou superior em:
    echo     https://www.python.org/downloads/
    echo e marque a opcao "Add Python to PATH" durante a instalacao.
    echo.
    pause
    exit /b 1
)
echo [OK] Python encontrado:
%PYEXE% --version
echo.

REM --- 2) Criar ambiente isolado (.appenv) ---
if exist ".appenv\Scripts\python.exe" (
    echo [1/3] Ambiente isolado .appenv ja existe.
) else (
    echo [1/3] Criando ambiente isolado .appenv ...
    %PYEXE% -m venv .appenv
    if errorlevel 1 (
        echo [ERRO] Falha ao criar o ambiente virtual.
        pause
        exit /b 1
    )
)

REM --- 3) Instalar dependencias dentro do .appenv ---
echo [2/3] Atualizando pip ...
call ".appenv\Scripts\python.exe" -m pip install --upgrade pip
echo [3/3] Instalando dependencias (customtkinter) ...
call ".appenv\Scripts\python.exe" -m pip install customtkinter
if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao instalar as dependencias.
    pause
    exit /b 1
)

echo.
echo ==================================================
echo    Instalacao concluida com sucesso!
echo.
echo    Para abrir SEM janela de console, use:
echo        Iniciar PyExec.vbs
echo.
echo    Para abrir em modo depuracao (com console), use:
echo        Iniciar PyExec (debug).bat
echo ==================================================
echo.
pause
