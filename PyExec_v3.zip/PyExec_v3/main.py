"""
Ponto de entrada — Py Executer Ultimate v3.0 (CustomTkinter).

Uso:
    python main.py

Requer CustomTkinter:
    pip install -r requirements.txt
"""
import sys


def main() -> None:
    try:
        import customtkinter  # noqa: F401
    except ImportError:
        print("CustomTkinter não encontrado. Instale com:\n    pip install customtkinter")
        sys.exit(1)

    from pyexec.app import main as run_app
    run_app()


if __name__ == "__main__":
    main()
