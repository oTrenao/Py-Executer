"""
Paleta e constantes visuais — herda o "Design System V16" do HTA original.
Tema escuro estilo GitHub. Centralizar aqui evita strings mágicas espalhadas.
"""

# --- Cores base ---
BG          = "#0d1117"   # fundo principal
BG_PANEL    = "#161b22"   # painéis / header
BG_INPUT    = "#0d1117"   # campos
BG_ELEV     = "#21262d"   # elementos elevados (panel-head, badges)
BORDER      = "#30363d"   # bordas
BORDER_SOFT = "#484f58"

TEXT        = "#c9d1d9"   # texto principal
TEXT_MUTED  = "#8b949e"   # texto secundário

# --- Acentos ---
ACCENT      = "#58a6ff"   # azul (links, abas ativas)
BLUE        = "#1f6feb"
GREEN       = "#238636"   # sucesso / ações primárias
GREEN_HOVER = "#2ea043"
GREEN_TEXT  = "#3fb950"
RED         = "#da3633"   # perigo
RED_HOVER   = "#f85149"
YELLOW      = "#d29922"   # aviso / "executando"
PURPLE      = "#6f42c1"   # UPX

CONSOLE_BG  = "#010409"
CONSOLE_FG  = "#3fb950"

# --- Tipografia ---
FONT_UI     = ("Segoe UI", 12)
FONT_UI_BOLD = ("Segoe UI", 12, "bold")
FONT_SMALL  = ("Segoe UI", 10)
FONT_MONO   = ("Consolas", 11)
FONT_TITLE  = ("Segoe UI", 14, "bold")

# --- Raios e espaçamentos ---
RADIUS = 6
PAD = 8
