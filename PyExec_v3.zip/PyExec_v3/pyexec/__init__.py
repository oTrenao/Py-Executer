"""
Py Executer Ultimate — v3.0 (CustomTkinter).
Reescrita do núcleo (antes em HTA/JScript) para Python nativo.

Camadas:
    pyexec.core  -> lógica sem UI (Python/venv, execução, imports). Testável isoladamente.
    pyexec.ui    -> widgets CustomTkinter.
    pyexec.app   -> janela principal que junta tudo.
"""

__version__ = "3.0.0-alpha"
APP_NAME = "Py Executer Ultimate"
