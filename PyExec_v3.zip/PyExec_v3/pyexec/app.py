"""
Janela principal do Py Executer Ultimate v3.0 (CustomTkinter).

Esta é a FUNDAÇÃO: monta o shell completo (sidebar, abas, console) e entrega
a aba EXECUTAR 100% funcional com streaming real. As abas Builder/Tools/Sistema
aparecem como placeholders e serão portadas nas próximas fases.
"""
from __future__ import annotations

import os
import tkinter as tk
from pathlib import Path
from tkinter import filedialog

import customtkinter as ctk

from . import APP_NAME, __version__, theme
from .core import builder, config, imports, pyenv, runner
from .core.builder import BuildOptions
from .ui.build_tab import BuildTab
from .ui.console import Console
from .ui.run_tab import RunTab
from .ui.system_tab import SystemTab
from .ui.tools_tab import ToolsTab

ctk.set_appearance_mode("dark")
IS_WINDOWS = os.name == "nt"


class PyExecApp(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"{APP_NAME}  ·  v{__version__}")
        self.geometry("1000x660")
        self.minsize(880, 560)
        self.configure(fg_color=theme.BG)

        self.cwd: Path = Path.cwd()
        self.interp_map: dict[str, str] = {}   # label -> caminho do python
        self.run_handle: runner.RunHandle | None = None

        self._build_header()
        self._build_body()
        self._build_console()

        self.refresh_interpreters()
        self.refresh_files()
        self.refresh_env()
        self.refresh_profiles()
        self._load_saved_config()

        # Salvar config ao fechar.
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        # Loop de saída e atualização periódica do ambiente.
        self.after(80, self._poll_output)
        self.after(3000, self._env_tick)

    # ------------------------------------------------------------------ UI
    def _build_header(self) -> None:
        header = ctk.CTkFrame(self, fg_color=theme.BG_PANEL, corner_radius=0, height=46)
        header.pack(fill="x")
        header.pack_propagate(False)

        ctk.CTkLabel(
            header, text="🐍 Py Executer", font=theme.FONT_TITLE, text_color=theme.ACCENT
        ).pack(side="left", padx=(14, 6))
        ctk.CTkLabel(
            header, text=f"ULTIMATE {__version__}", font=theme.FONT_SMALL,
            text_color=theme.TEXT_MUTED,
        ).pack(side="left")

        self.env_indicator = ctk.CTkLabel(
            header, text="...", font=theme.FONT_SMALL, text_color=theme.TEXT_MUTED,
            fg_color=theme.BG_ELEV, corner_radius=10, padx=12, pady=2,
        )
        self.env_indicator.pack(side="right", padx=10)
        ctk.CTkButton(
            header, text="CMD", width=56, font=theme.FONT_SMALL,
            fg_color=theme.BG_ELEV, hover_color=theme.BORDER, command=self.open_cmd,
        ).pack(side="right", padx=4)

    def _build_body(self) -> None:
        body = ctk.CTkFrame(self, fg_color="transparent")
        body.pack(fill="both", expand=True)

        self._build_sidebar(body)

        content = ctk.CTkFrame(body, fg_color="transparent")
        content.pack(side="left", fill="both", expand=True, padx=(0, 8), pady=8)

        self.tabs = ctk.CTkTabview(
            content, fg_color=theme.BG, segmented_button_selected_color=theme.BLUE,
            segmented_button_selected_hover_color=theme.ACCENT,
        )
        self.tabs.pack(fill="both", expand=True)
        tab_run = self.tabs.add("▶ Executar")
        tab_build = self.tabs.add("🔨 Builder")
        tab_tools = self.tabs.add("🛠 Tools")
        tab_sys = self.tabs.add("⚙ Sistema")

        self.run_tab = RunTab(tab_run, self)
        self.run_tab.pack(fill="both", expand=True)
        self.build_tab = BuildTab(tab_build, self)
        self.build_tab.pack(fill="both", expand=True)
        self.tools_tab = ToolsTab(tab_tools, self)
        self.tools_tab.pack(fill="both", expand=True)
        self.system_tab = SystemTab(tab_sys, self)
        self.system_tab.pack(fill="both", expand=True)

    def _build_sidebar(self, parent) -> None:
        side = ctk.CTkFrame(parent, fg_color=theme.BG, width=250, corner_radius=0)
        side.pack(side="left", fill="y", padx=8, pady=8)
        side.pack_propagate(False)

        # Explorador
        exp = ctk.CTkFrame(side, fg_color=theme.BG_PANEL, border_color=theme.BORDER,
                           border_width=1, corner_radius=theme.RADIUS)
        exp.pack(fill="both", expand=True)
        _head(exp, "Explorador")

        self.file_list = tk.Listbox(
            exp, bg=theme.BG_INPUT, fg=theme.TEXT, selectbackground=theme.BLUE,
            selectforeground="white", borderwidth=0, highlightthickness=0,
            font=("Consolas", 10), activestyle="none",
        )
        self.file_list.pack(fill="both", expand=True, padx=6, pady=6)

        brow = ctk.CTkFrame(exp, fg_color="transparent")
        brow.pack(fill="x", padx=6, pady=(0, 6))
        ctk.CTkButton(brow, text="↻", width=34, command=self.refresh_files,
                      fg_color=theme.BG_ELEV, hover_color=theme.BORDER).pack(side="left")
        ctk.CTkButton(brow, text="+ Novo", command=self.new_script,
                      fg_color=theme.GREEN, hover_color=theme.GREEN_HOVER).pack(
            side="left", expand=True, fill="x", padx=4)
        ctk.CTkButton(brow, text="📝", width=34, command=self.open_script,
                      fg_color=theme.BG_ELEV, hover_color=theme.BORDER).pack(side="left")
        ctk.CTkButton(exp, text="📂 Escolher Pasta", command=self.choose_folder,
                      fg_color=theme.BG_ELEV, hover_color=theme.BORDER).pack(
            fill="x", padx=6, pady=(0, 8))

        # Ambiente Python
        env = ctk.CTkFrame(side, fg_color=theme.BG_PANEL, border_color=theme.BORDER,
                           border_width=1, corner_radius=theme.RADIUS)
        env.pack(fill="x", pady=(8, 0))
        _head(env, "Ambiente Python")
        self.interp_menu = ctk.CTkOptionMenu(
            env, values=["..."], command=lambda _=None: self.refresh_env(),
            fg_color=theme.BG_INPUT, button_color=theme.BG_ELEV,
            button_hover_color=theme.BORDER, font=theme.FONT_SMALL,
        )
        self.interp_menu.pack(fill="x", padx=6, pady=6)
        vrow = ctk.CTkFrame(env, fg_color="transparent")
        vrow.pack(fill="x", padx=6, pady=(0, 6))
        self.btn_create_venv = ctk.CTkButton(
            vrow, text="Criar Venv", command=self.create_venv,
            fg_color=theme.BLUE, hover_color=theme.ACCENT)
        self.btn_create_venv.pack(side="left", expand=True, fill="x", padx=(0, 4))
        ctk.CTkButton(vrow, text="🔧 Pip", width=60, command=self.fix_pip,
                      fg_color=theme.BG_ELEV, hover_color=theme.BORDER).pack(side="left")

    def _build_console(self) -> None:
        self.console = Console(self)
        self.console.pack(fill="x", side="bottom")
        self.console.btn_stop.configure(command=self.stop)
        self.console.btn_save.configure(command=self.save_log)

    # -------------------------------------------------------------- helpers
    def selected_script(self) -> str | None:
        sel = self.file_list.curselection()
        if not sel:
            return None
        return self.file_list.get(sel[0])

    def current_python(self) -> str:
        label = self.interp_menu.get()
        return self.interp_map.get(label, "global")

    def log(self, msg: str) -> None:
        self.console.write(msg)

    # ------------------------------------------------------------- ações
    def refresh_interpreters(self) -> None:
        interps = pyenv.detect_interpreters()
        self.interp_map = {i.label: i.path for i in interps}
        labels = list(self.interp_map.keys())
        self.interp_menu.configure(values=labels)
        if labels:
            self.interp_menu.set(labels[0])

    def refresh_files(self) -> None:
        self.file_list.delete(0, "end")
        try:
            scripts = sorted(p.name for p in self.cwd.glob("*.py"))
        except OSError:
            scripts = []
        for name in scripts:
            self.file_list.insert("end", name)
        if scripts:
            self.file_list.selection_set(0)

    def refresh_env(self) -> None:
        info = pyenv.resolve_env(self.cwd, self.current_python())
        color = theme.ACCENT if info.kind == "venv" else theme.YELLOW
        self.env_indicator.configure(text=info.label, text_color=color)
        # Em venv não faz sentido "Criar Venv".
        self.btn_create_venv.configure(state="disabled" if info.kind == "venv" else "normal")

    def choose_folder(self) -> None:
        folder = filedialog.askdirectory(initialdir=str(self.cwd))
        if folder:
            self.cwd = Path(folder)
            self.refresh_files()
            self.refresh_env()
            self.log(f"Pasta de trabalho: {folder}")

    def new_script(self) -> None:
        dialog = ctk.CTkInputDialog(text="Nome do script (sem .py):", title="Novo Script")
        name = dialog.get_input()
        if not name:
            return
        path = self.cwd / f"{name}.py"
        if path.exists():
            self.log("⚠ Arquivo já existe.")
            return
        path.write_text("print('Py Executer v3')\ninput('Enter para sair...')\n", encoding="utf-8")
        self.refresh_files()

    def open_script(self) -> None:
        script = self.selected_script()
        if script and IS_WINDOWS:
            os.startfile(str(self.cwd / script))  # type: ignore[attr-defined]

    def open_cmd(self) -> None:
        if IS_WINDOWS:
            runner.run(f'start cmd /k cd /d "{self.cwd}"')

    def run_script(self) -> None:
        if self.run_handle and self.run_handle.running:
            self.log("⚠ Já existe uma execução em andamento.")
            return
        script = self.selected_script()
        if not script:
            self.log("⚠ Selecione um arquivo .py.")
            return
        info = pyenv.resolve_env(self.cwd, self.current_python())

        if self.run_tab.interactive.get() and IS_WINDOWS:
            exe = "python" if info.python == "global" else info.python
            runner.run(f'start "PyExec - {script}" cmd /k ""{exe}" -u "{script}""', cwd=str(self.cwd))
            self.log(f"▶ Iniciado em janela externa: {script}")
            return

        args = runner.build_run_args(info.python, script)
        self.console.set_status("Executando...", theme.YELLOW)
        self.console.set_running(True)
        self.log(f"--- Executando {script} ({info.label}) ---")
        self.run_handle = runner.run(args, cwd=str(self.cwd))

    def stop(self) -> None:
        if self.run_handle:
            runner.stop(self.run_handle)
            self.log("[INTERROMPIDO] Processo desta execução encerrado.")
        self.console.set_running(False)
        self.console.set_status("■ Parado", theme.TEXT_MUTED)

    def check_dependencies(self) -> None:
        script = self.selected_script()
        if not script:
            self.log("⚠ Selecione um arquivo .py.")
            return
        src = (self.cwd / script).read_text(encoding="utf-8", errors="replace")
        reqs = imports.third_party_requirements(src)
        self.log("🔍 Dependências externas: " + (", ".join(reqs) if reqs else "(nenhuma)"))

    def install_missing(self) -> None:
        script = self.selected_script()
        if not script:
            self.log("⚠ Selecione um arquivo .py.")
            return
        src = (self.cwd / script).read_text(encoding="utf-8", errors="replace")
        reqs = imports.third_party_requirements(src)
        if not reqs:
            self.log("Nada a instalar.")
            return
        info = pyenv.resolve_env(self.cwd, self.current_python())
        exe = "python" if info.python == "global" else info.python
        args = [exe, "-m", "pip", "install", *reqs]
        self.console.set_status("Instalando...", theme.YELLOW)
        self.console.set_running(True)
        self.log("⬇ pip install " + " ".join(reqs))
        self.run_handle = runner.run(args, cwd=str(self.cwd))

    def create_venv(self) -> None:
        args = pyenv.create_venv_cmd(self.current_python())
        self.console.set_status("Criando venv...", theme.YELLOW)
        self.console.set_running(True)
        self.log("--- Criando venv ---")
        self.run_handle = runner.run(args, cwd=str(self.cwd))

    def fix_pip(self) -> None:
        info = pyenv.resolve_env(self.cwd, self.current_python())
        exe = "python" if info.python == "global" else info.python
        self.console.set_status("Atualizando pip...", theme.YELLOW)
        self.console.set_running(True)
        self.run_handle = runner.run([exe, "-m", "pip", "install", "--upgrade", "pip"], cwd=str(self.cwd))

    def save_log(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".txt", initialfile="pyexec_log.txt",
            initialdir=str(self.cwd), filetypes=[("Texto", "*.txt")],
        )
        if path:
            Path(path).write_text(self.console.get_text(), encoding="utf-8")
            self.log(f"✓ Log salvo: {path}")

    # --------------------------------------------------------- util execução
    def _python_exe(self) -> str:
        info = pyenv.resolve_env(self.cwd, self.current_python())
        return "python" if info.python == "global" else info.python

    def _selected_source(self) -> str:
        script = self.selected_script()
        if not script:
            return ""
        return (self.cwd / script).read_text(encoding="utf-8", errors="replace")

    def _start(self, cmd, status: str = "Executando...", desc: str | None = None) -> None:
        if self.run_handle and self.run_handle.running:
            self.log("⚠ Já existe uma execução em andamento.")
            return
        if desc:
            self.log(desc)
        self.console.set_status(status, theme.YELLOW)
        self.console.set_running(True)
        self.run_handle = runner.run(cmd, cwd=str(self.cwd))

    # ----------------------------------------------------------- Builder
    def validate_mode(self) -> None:
        if self.build_tab.mode.get() == "--accelerated" and not self.build_tab.nuitka.get():
            self.build_tab.nuitka.select()
            self.build_tab.toggle_nuitka()
            self.log("ℹ Accelerated exige Nuitka — Nuitka foi ativado.")

    def pick_icon(self) -> None:
        path = filedialog.askopenfilename(
            initialdir=str(self.cwd),
            filetypes=[("Ícones/Imagens", "*.ico *.png *.jpg *.jpeg")])
        if path:
            self.build_tab.set_icon(path)

    def pick_into(self, entry) -> None:
        folder = filedialog.askdirectory(initialdir=str(self.cwd))
        if folder:
            entry.delete(0, "end")
            entry.insert(0, folder)

    def add_data_path(self, is_dir: bool) -> None:
        if is_dir:
            path = filedialog.askdirectory(initialdir=str(self.cwd))
        else:
            path = filedialog.askopenfilename(initialdir=str(self.cwd))
        if path:
            name = Path(path).name
            self.build_tab.data_box.insert("end", f"{path}={name}\n")

    def scan_collect(self) -> None:
        src = self._selected_source()
        if not src:
            self.log("⚠ Selecione um arquivo .py.")
            return
        found = builder.suggest_collect(src, self.build_tab.nuitka.get())
        self.build_tab.collect.delete(0, "end")
        self.build_tab.collect.insert(0, " ".join(found))
        self.log("🔍 Collect sugerido: " + (", ".join(found) if found else "(nenhum)"))

    def scan_exclude(self) -> None:
        src = self._selected_source()
        if not src:
            self.log("⚠ Selecione um arquivo .py.")
            return
        found = builder.suggest_excludes(src)
        self.build_tab.exclude.delete(0, "end")
        self.build_tab.exclude.insert(0, " ".join(found))
        self.log(f"🔍 Exclude sugerido: {len(found)} módulo(s).")

    def _prepare_icon(self, icon: str) -> str:
        if not icon or icon.lower().endswith(".ico"):
            return icon
        try:
            from PIL import Image
            out = str(self.cwd / "temp_icon.ico")
            Image.open(icon).save(out, sizes=[(256, 256)])
            self.log("🖼 Ícone convertido para .ico.")
            return out
        except Exception as exc:
            self.log(f"⚠ Não foi possível converter o ícone ({exc}). Usando sem ícone.")
            return ""

    def _build_opts(self):
        script = self.selected_script()
        if not script:
            self.log("⚠ Selecione um arquivo .py.")
            return None
        opts = self.build_tab.get_options(script)
        if opts.mode == "--accelerated" and not opts.use_nuitka:
            self.log("⚠ Accelerated é exclusivo do Nuitka.")
            return None
        return opts

    def preview_build(self) -> None:
        opts = self._build_opts()
        if not opts:
            return
        cmd = builder.preview(opts, self._selected_source(), self._python_exe())
        self.log("\n===== COMANDO GERADO =====\n" + cmd + "\n==========================")

    def build_exe(self) -> None:
        opts = self._build_opts()
        if not opts:
            return
        if opts.clean_build:
            self.log("ℹ Build limpo (venv temp) será portado em breve; compilando no ambiente atual.")
        opts.icon = self._prepare_icon(opts.icon)
        cmd, desc = builder.build_command(opts, self._selected_source(), self._python_exe())
        self._start(cmd, status="Compilando...", desc=f"--- {desc}: {opts.script} ---")

    # ----------------------------------------------------------- Perfis
    def refresh_profiles(self) -> None:
        names = config.list_profiles()
        self.build_tab.profile_menu.configure(values=names or ["— perfis —"])
        if names:
            self.build_tab.profile_menu.set(names[0])

    def save_profile(self) -> None:
        dialog = ctk.CTkInputDialog(text="Nome do perfil:", title="Salvar Perfil")
        name = dialog.get_input()
        if not name:
            return
        safe = config.save_profile(name, self.build_tab.as_dict())
        self.refresh_profiles()
        self.build_tab.profile_menu.set(safe)
        self.log(f"✓ Perfil salvo: {safe}")

    def load_profile(self) -> None:
        name = self.build_tab.profile_menu.get()
        data = config.load_profile(name)
        if data is None:
            self.log("⚠ Selecione um perfil válido.")
            return
        self.build_tab.apply(data)
        self.log(f"✓ Perfil carregado: {name}")

    def delete_profile(self) -> None:
        name = self.build_tab.profile_menu.get()
        if config.delete_profile(name):
            self.log(f"Perfil excluído: {name}")
            self.refresh_profiles()

    # ----------------------------------------------------------- Config
    def _collect_config(self) -> dict:
        data = self.build_tab.as_dict()
        data["interpreter"] = self.interp_menu.get()
        data["interactive"] = bool(self.run_tab.interactive.get())
        return data

    def _load_saved_config(self) -> None:
        data = config.load_config()
        if not data:
            return
        self.build_tab.apply(data)
        if data.get("interpreter") in self.interp_map:
            self.interp_menu.set(data["interpreter"])
        if data.get("interactive"):
            self.run_tab.interactive.select()
        self.refresh_env()

    def save_config_now(self) -> None:
        config.save_config(self._collect_config())
        self.log("✓ Configuração salva.")

    def _on_close(self) -> None:
        try:
            config.save_config(self._collect_config())
        except Exception:
            pass
        self.destroy()

    # ----------------------------------------------------------- Tools
    def run_tool(self, args, needs_file: bool) -> None:
        py = self._python_exe()
        cmd = [py, "-m", *args]
        if needs_file:
            script = self.selected_script()
            if not script:
                self.log("⚠ Selecione um arquivo .py.")
                return
            cmd.append(script)
        self._start(cmd, desc="--- " + " ".join(args) + " ---")

    def install_kit(self) -> None:
        py = self._python_exe()
        kit = ["pylint", "black", "bandit", "ruff", "mypy", "pytest", "pip-audit",
               "pyinstaller", "nuitka", "ordered-set", "zstandard", "pillow", "pyarmor"]
        self._start([py, "-m", "pip", "install", *kit],
                    status="Instalando kit...", desc="--- Instalar Kit Dev ---")

    def gen_requirements_scan(self) -> None:
        src = self._selected_source()
        if not src:
            self.log("⚠ Selecione um arquivo .py.")
            return
        reqs = imports.third_party_requirements(src)
        if not reqs:
            self.log("Nenhuma dependência externa detectada.")
            return
        (self.cwd / "requirements.txt").write_text("\n".join(reqs) + "\n", encoding="utf-8")
        self.log(f"✓ requirements.txt gerado ({len(reqs)} pacote(s)): " + ", ".join(reqs))

    def gen_requirements_freeze(self) -> None:
        py = self._python_exe()
        self._start(f'"{py}" -m pip freeze > requirements.txt',
                    desc="--- Gerar requirements.txt (freeze) ---")

    def check_outdated(self) -> None:
        self._start([self._python_exe(), "-m", "pip", "list", "--outdated"],
                    desc="--- Dependências desatualizadas ---")

    def update_all_outdated(self) -> None:
        py = self._python_exe()
        if os.name == "nt":
            cmd = (f'for /F "skip=2 tokens=1" %i in (\'"{py}" -m pip list --outdated\') '
                   f'do "{py}" -m pip install -U %i')
        else:
            cmd = f'"{py}" -m pip list --outdated'
        self._start(cmd, status="Atualizando...", desc="--- Atualizar dependências ---")

    # ----------------------------------------------------------- Sistema
    def clean_cache(self) -> None:
        if os.name != "nt":
            self.log("Limpeza automática disponível apenas no Windows.")
            return
        cmd = (
            "if exist build rmdir /s /q build & "
            "if exist dist rmdir /s /q dist & "
            "if exist __pycache__ rmdir /s /q __pycache__ & "
            "if exist temp_icon.ico del /q temp_icon.ico & "
            'for /d %i in (*.build) do @rmdir /s /q "%i" & '
            'for /d %i in (*.dist) do @rmdir /s /q "%i" & '
            'for /d %i in (*.onefile-build) do @rmdir /s /q "%i" & '
            "echo [OK] Cache limpo."
        )
        self._start(cmd, desc="--- Limpar Lixo de Build ---")

    def manual_pip_install(self, lib: str) -> None:
        lib = (lib or "").strip()
        if not lib:
            return
        self._start([self._python_exe(), "-m", "pip", "install", *lib.split()],
                    desc=f"--- pip install {lib} ---")

    # ------------------------------------------------------- loops de fundo
    def _poll_output(self) -> None:
        h = self.run_handle
        if h is not None:
            for line in runner.drain(h):
                self.console.write(line)
            if not h.running and h.returncode is not None:
                code = h.returncode
                self.run_handle = None
                self.console.set_running(False)
                if code == 0:
                    self.console.set_status("✓ Concluído", theme.GREEN_TEXT)
                    self.log("✓ Operação concluída (código 0).")
                else:
                    self.console.set_status(f"✗ Erro (código {code})", theme.RED_HOVER)
                    self.log(f"✗ Falhou — código de saída {code}.")
                self.refresh_files()
                self.refresh_env()
        self.after(80, self._poll_output)

    def _env_tick(self) -> None:
        if not (self.run_handle and self.run_handle.running):
            self.refresh_env()
        self.after(3000, self._env_tick)


def _head(parent, title: str) -> None:
    head = ctk.CTkFrame(parent, fg_color=theme.BG_ELEV, corner_radius=0, height=26)
    head.pack(fill="x")
    head.pack_propagate(False)
    ctk.CTkLabel(head, text=title.upper(), font=theme.FONT_SMALL,
                 text_color=theme.TEXT_MUTED).pack(side="left", padx=10)


def main() -> None:
    app = PyExecApp()
    app.mainloop()
