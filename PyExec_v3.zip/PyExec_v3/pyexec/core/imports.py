"""
Análise de imports via AST.

Substitui o parsing por substring/indexOf do HTA, que dava falsos positivos
(uma palavra num comentário ou string acionava plugins) e perdia casos como
`import a, b, c`. Aqui usamos o parser real do Python, então o resultado é exato.
"""
from __future__ import annotations

import ast
import sys

# Nome de módulo importado -> nome do pacote no PyPI (quando diferem).
LIB_MAP = {
    "cv2": "opencv-python",
    "serial": "pyserial",
    "PIL": "pillow",
    "win32api": "pywin32",
    "win32con": "pywin32",
    "win32gui": "pywin32",
    "bs4": "beautifulsoup4",
    "sklearn": "scikit-learn",
    "yaml": "pyyaml",
    "discord": "discord.py",
    "dotenv": "python-dotenv",
    "fitz": "pymupdf",
    "firebase_admin": "firebase-admin",
    "usb": "pyusb",
}

# Conjunto de módulos da biblioteca padrão (preciso, vindo do próprio interpretador).
_STDLIB = set(getattr(sys, "stdlib_module_names", set()))


def parse_imports(source: str) -> list[str]:
    """Retorna os nomes de módulo de TOPO importados no código (sem duplicar).

    Ignora imports relativos (`from . import x`). Se o código tiver erro de
    sintaxe, faz um fallback linha-a-linha tolerante para ainda extrair algo.
    """
    names: list[str] = []

    def add(name: str) -> None:
        if name and name not in names:
            names.append(name)

    try:
        tree = ast.parse(source)
    except SyntaxError:
        return _fallback_parse(source)

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                add(alias.name.split(".")[0])
        elif isinstance(node, ast.ImportFrom):
            if node.level and node.level > 0:
                continue  # import relativo: não é dependência externa
            if node.module:
                add(node.module.split(".")[0])
    return names


def _fallback_parse(source: str) -> list[str]:
    names: list[str] = []
    for raw in source.splitlines():
        line = raw.strip()
        if line.startswith("import "):
            body = line[7:].split("#")[0]
            for part in body.split(","):
                seg = part.strip().split(" ")[0]
                if seg and not seg.startswith("."):
                    top = seg.split(".")[0]
                    if top not in names:
                        names.append(top)
        elif line.startswith("from "):
            seg = line[5:].strip().split(" ")[0]
            if seg and not seg.startswith("."):
                top = seg.split(".")[0]
                if top not in names:
                    names.append(top)
    return names


def is_stdlib(module: str) -> bool:
    return module in _STDLIB


def third_party_requirements(source: str) -> list[str]:
    """Imports externos já mapeados para o nome de pacote do PyPI, sem stdlib."""
    reqs: list[str] = []
    for mod in parse_imports(source):
        if is_stdlib(mod):
            continue
        pkg = LIB_MAP.get(mod, mod)
        if pkg not in reqs:
            reqs.append(pkg)
    return reqs
