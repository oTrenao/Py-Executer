"""
Execução de processos com streaming de saída em tempo real.

Este módulo é o coração da migração. No HTA, executar qualquer coisa significava:
gerar um .bat -> redirecionar para um arquivo de log -> ler o log a cada 500ms ->
adivinhar o término por uma substring. Aqui usamos subprocess.Popen direto:

  * a saída (stdout+stderr juntos) é lida linha a linha por uma thread;
  * cada linha vai para uma fila thread-safe que a UI consome sem travar;
  * o término traz o código de saída REAL (proc.returncode);
  * o Stop encerra exatamente este processo e seus filhos (pelo PID), sem
    matar outros Python da máquina.
"""
from __future__ import annotations

import os
import queue
import subprocess
import threading
from dataclasses import dataclass
from typing import Callable

IS_WINDOWS = os.name == "nt"


@dataclass
class RunHandle:
    """Referência viva a uma execução em andamento."""
    process: subprocess.Popen
    output: "queue.Queue[str]"
    _done: threading.Event

    @property
    def pid(self) -> int:
        return self.process.pid

    @property
    def running(self) -> bool:
        return self.process.poll() is None

    @property
    def returncode(self) -> int | None:
        return self.process.poll()

    def wait_done(self, timeout: float | None = None) -> bool:
        return self._done.wait(timeout)


def run(
    args: list[str] | str,
    cwd: str | None = None,
    env: dict | None = None,
    on_done: Callable[[int], None] | None = None,
) -> RunHandle:
    """Inicia um processo e devolve um RunHandle. Não bloqueia.

    `args` pode ser uma lista (preferível) ou string (quando precisar de shell).
    `on_done` é chamado, numa thread de fundo, com o returncode ao terminar.
    """
    use_shell = isinstance(args, str)

    creationflags = 0
    if IS_WINDOWS:
        # Novo grupo de processos: permite encerrar a árvore de forma limpa.
        creationflags = subprocess.CREATE_NEW_PROCESS_GROUP

    proc = subprocess.Popen(
        args,
        cwd=cwd,
        env=env,
        shell=use_shell,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
        bufsize=1,
        universal_newlines=True,
        encoding="utf-8",
        errors="replace",
        creationflags=creationflags,
    )

    out_q: "queue.Queue[str]" = queue.Queue()
    done = threading.Event()

    def _pump() -> None:
        try:
            assert proc.stdout is not None
            for line in proc.stdout:
                out_q.put(line.rstrip("\n"))
        except Exception as exc:  # pragma: no cover - robustez
            out_q.put(f"[runner] erro ao ler saída: {exc}")
        finally:
            code = proc.wait()
            done.set()
            if on_done is not None:
                on_done(code)

    threading.Thread(target=_pump, daemon=True).start()
    return RunHandle(process=proc, output=out_q, _done=done)


def stop(handle: RunHandle) -> None:
    """Encerra o processo e TODA a sua árvore de filhos — só este, mais nada."""
    if handle is None or not handle.running:
        return
    pid = handle.pid
    if IS_WINDOWS:
        # taskkill /T derruba o processo e os filhos (ex.: o python que ele lançou).
        subprocess.run(
            ["taskkill", "/F", "/T", "/PID", str(pid)],
            capture_output=True,
        )
    else:
        try:
            handle.process.terminate()
        except Exception:
            pass


def drain(handle: RunHandle, max_lines: int = 500) -> list[str]:
    """Retira até `max_lines` linhas já disponíveis (uso da UI a cada tick)."""
    lines: list[str] = []
    try:
        while len(lines) < max_lines:
            lines.append(handle.output.get_nowait())
    except queue.Empty:
        pass
    return lines


def build_run_args(python: str, script: str, unbuffered: bool = True) -> list[str]:
    """Monta os argumentos para rodar um script com o interpretador resolvido."""
    exe = "python" if python == "global" else python
    args = [exe]
    if unbuffered:
        args.append("-u")
    args.append(script)
    return args
