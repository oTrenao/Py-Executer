"""Núcleo sem UI: pode ser importado e testado isoladamente."""
from . import builder, config, imports, pyenv, runner  # noqa: F401
