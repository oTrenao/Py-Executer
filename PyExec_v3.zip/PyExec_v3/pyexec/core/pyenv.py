"""
Detecção de interpretadores Python e de ambientes virtuais.

Equivale a LoadPythonVersions/GetEnvInfo/CheckEnv do HTA, mas em Python e
sem ActiveX. A resolução do interpretador a ser usado segue a prioridade:
venv local detectada > seleção do usuário > Python global do PATH.
"""
from __future__ import annotations

import os
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

IS_WINDOWS = os.name == "nt"
VENV_NAMES = ("venv", ".venv", "env")


@dataclass
class PyInterp:
    label: str          # texto amigável p/ o combo
    path: str           # caminho do python.exe (ou "global")

    @property
    def is_global(self) -> bool:
        return self.path == "global"


@dataclass
class EnvInfo:
    kind: str           # "venv" | "global" | "custom"
    python: str         # executável a usar
    label: str
    activate: str | None = None  # caminho do activate.bat (só venv, p/ abrir CMD)


def _venv_python(folder: Path) -> Path:
    return folder / ("Scripts/python.exe" if IS_WINDOWS else "bin/python")


def detect_venv(cwd: Path) -> Path | None:
    """Procura uma venv local (venv/.venv/env) na pasta de trabalho."""
    for name in VENV_NAMES:
        folder = cwd / name
        if _venv_python(folder).exists():
            return folder
    return None


def detect_interpreters() -> list[PyInterp]:
    """Lista os Pythons disponíveis. Sempre inclui a opção Global (PATH)."""
    found: list[PyInterp] = [PyInterp("🌐 Global (PATH)", "global")]
    seen: set[str] = set()

    candidates: list[Path] = []
    if IS_WINDOWS:
        for ver in ("313", "312", "311", "310", "39"):
            candidates.append(Path(f"C:/Python{ver}"))
        local = os.environ.get("LOCALAPPDATA")
        if local:
            base = Path(local) / "Programs" / "Python"
            if base.exists():
                candidates.extend(p for p in base.iterdir() if p.is_dir())
        # Também consulta o py launcher, se existir.
        candidates.extend(_py_launcher_paths())
    else:
        # Fallback unix (para desenvolvimento/testes): usa o python atual.
        candidates.append(Path(sys.executable).parent)

    for folder in candidates:
        exe = folder / ("python.exe" if IS_WINDOWS else "python3")
        if not exe.exists():
            exe = folder / "python"
        if exe.exists():
            key = str(exe).lower()
            if key in seen:
                continue
            seen.add(key)
            found.append(PyInterp("🐍 " + folder.name, str(exe)))
    return found


def _py_launcher_paths() -> list[Path]:
    try:
        out = subprocess.run(
            ["py", "-0p"], capture_output=True, text=True, timeout=5
        ).stdout
    except Exception:
        return []
    paths: list[Path] = []
    for line in out.splitlines():
        line = line.strip()
        # Formato típico: "-V:3.12 *        C:\...\python.exe"
        idx = line.lower().find("python.exe")
        if idx > -1:
            # pega o caminho (último token que termina em python.exe)
            for token in line.replace("\t", " ").split(" "):
                if token.lower().endswith("python.exe"):
                    paths.append(Path(token).parent)
    return paths


def resolve_env(cwd: Path, selected_path: str) -> EnvInfo:
    """Decide qual ambiente usar, dada a pasta e a seleção do combo."""
    venv = detect_venv(cwd)
    if venv is not None:
        return EnvInfo(
            kind="venv",
            python=str(_venv_python(venv)),
            label=f"⚡ VENV ATIVA ({venv.name})",
            activate=str(venv / "Scripts" / "activate.bat"),
        )
    if selected_path == "global" or not selected_path:
        return EnvInfo(kind="global", python=sys.executable if not IS_WINDOWS else "python",
                       label="🌐 Global (PATH)")
    return EnvInfo(kind="custom", python=selected_path, label="🐍 " + Path(selected_path).parent.name)


def create_venv_cmd(python: str) -> list[str]:
    base = "python" if python == "global" else python
    return [base, "-m", "venv", "venv"]
