"""
Construção dos comandos de build (PyInstaller / Nuitka).

Toda a lógica que antes vivia dentro da função-monstro `BuildExe` do HTA (300+
linhas) está aqui, em funções puras e testáveis. A UI só coleta opções e chama
`build_command(...)`. A detecção de plugins/coleta usa o parser `ast` (imports.py),
então não há mais falso-positivo por substring.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path

from . import imports

IS_WINDOWS = os.name == "nt"

# Módulos que costumam precisar de coleta especial no empacotamento.
_COLLECT_HINTS = {
    "ultralytics", "torch", "tensorflow", "keras", "sklearn", "cv2", "PIL",
    "transformers", "onnx", "onnxruntime", "tensorrt", "dxcam",
    "tkinter", "pygame", "PyQt5", "PySide6", "kivy", "customtkinter", "dearpygui",
    "django", "flask", "fastapi", "selenium", "aiohttp", "websockets",
    "serial", "usb", "firebase_admin", "boto3",
    "cryptography", "sqlalchemy", "psycopg2", "pymongo", "redis",
}
# Módulos grandes que normalmente podem ser excluídos se não usados.
_EXCLUDE_CANDIDATES = [
    "unittest", "pytest", "nose", "sphinx", "docutils", "pydoc",
    "setuptools", "pip", "wheel", "distutils", "matplotlib", "scipy",
    "IPython", "jupyter",
]
# import -> plugin do Nuitka
_NUITKA_PLUGINS = {
    "tkinter": "tk-inter", "django": "django", "torch": "torch", "numpy": "numpy",
}


@dataclass
class BuildOptions:
    script: str
    mode: str = "--onefile"          # --onefile | --onedir | --accelerated
    no_console: bool = True
    use_nuitka: bool = False
    use_pyarmor: bool = False
    use_upx: bool = False
    clean_build: bool = False
    icon: str = ""                   # caminho .ico já convertido
    collect: str = ""                # separado por espaço
    exclude: str = ""                # separado por espaço
    # Nuitka avançado
    nuitka_clean_cache: bool = False
    nuitka_show_progress: bool = True
    nuitka_show_memory: bool = False
    nuitka_lto: str = "--lto=no"     # "" | --lto=no | --lto=yes
    nuitka_msvc: bool = False
    nuitka_output_dir: str = ""
    data_items: list[str] = field(default_factory=list)  # "src=dst" ou caminhos


def exe_name(script: str) -> str:
    return Path(script).stem


def suggest_collect(source: str, nuitka: bool = False) -> list[str]:
    found: list[str] = []
    for mod in imports.parse_imports(source):
        if mod in _COLLECT_HINTS and mod not in found:
            found.append(mod)
    if ("YOLO(" in source or ".pt" in source or ".onnx" in source) and "ultralytics" not in found:
        found.append("ultralytics")
    if "torch.cuda" in source and "torch" not in found:
        found.append("torch")
    return found


def suggest_excludes(source: str) -> list[str]:
    return [m for m in _EXCLUDE_CANDIDATES if m not in source]


def detect_nuitka_plugins(source: str) -> list[str]:
    plugins: list[str] = []
    mods = set(imports.parse_imports(source))
    for mod, plugin in _NUITKA_PLUGINS.items():
        if mod in mods and plugin not in plugins:
            plugins.append(plugin)
    return plugins


def _pyinstaller_args(opts: BuildOptions, python: str = "python") -> list[str]:
    name = exe_name(opts.script)
    args = [python, "-m", "PyInstaller", "--noconfirm", "--clean", opts.mode,
            "--noconsole" if opts.no_console else "--console", "--name", name]
    if opts.icon:
        args += ["--icon", opts.icon]
    args += ["--upx-dir", "."] if opts.use_upx else ["--noupx"]
    for mod in opts.collect.split():
        args += ["--collect-all", mod]
    for mod in opts.exclude.split():
        args += ["--exclude-module", mod]
    args += ["--hidden-import", "PIL", "--hidden-import", "cv2", opts.script]
    return args


def _nuitka_args(opts: BuildOptions, source: str = "", python: str = "python") -> list[str]:
    name = exe_name(opts.script)
    mode = {"--onefile": "--mode=onefile",
            "--accelerated": "--mode=accelerated"}.get(opts.mode, "--mode=standalone")
    args = [python, "-m", "nuitka", mode, "--assume-yes-for-downloads"]
    if opts.nuitka_show_progress:
        args.append("--show-progress")
    if opts.nuitka_show_memory:
        args.append("--show-memory")
    args.append("--windows-console-mode=disable" if opts.no_console
                else "--windows-console-mode=force")
    if opts.icon:
        args.append(f'--windows-icon-from-ico={opts.icon}')
    if opts.nuitka_clean_cache:
        args.append("--clean-cache=all")
    if opts.nuitka_msvc:
        args.append("--msvc=latest")
    elif opts.nuitka_lto:
        args.append(opts.nuitka_lto)
    out_dir = opts.nuitka_output_dir or name
    args.append(f'--output-dir={out_dir}')

    for plugin in detect_nuitka_plugins(source):
        args.append(f"--enable-plugin={plugin}")
    for mod in opts.collect.split():
        if mod and not imports.is_stdlib(mod):
            args.append(f"--include-package={mod}")
    for mod in opts.exclude.split():
        args.append(f"--nofollow-import-to={mod}")

    for item in opts.data_items:
        item = item.strip().strip('"')
        if not item:
            continue
        src = item.split("=")[0] if "=" in item else item
        if "=" not in item:
            item = f"{item}={Path(item).name}"
        if Path(src).is_dir():
            args.append(f'--include-data-dir={item}')
        else:
            args.append(f'--include-data-file={item}')

    args.append(f'--output-filename={name}.exe')
    args.append(opts.script)
    return args


def build_command(opts: BuildOptions, source: str = "", python: str = "python"):
    """Devolve (cmd, descricao).

    `cmd` é uma lista de args para o caso normal (execução direta, sem shell)
    ou uma string quando precisa de encadeamento (PyArmor). A UI passa qualquer
    um dos dois para runner.run().
    """
    if opts.use_nuitka:
        return _nuitka_args(opts, source, python), "Build Nuitka"

    if opts.use_pyarmor:
        name = exe_name(opts.script)
        obf = "dist\\obfuscated" if IS_WINDOWS else "dist/obfuscated"
        sep = ";" if IS_WINDOWS else ":"
        pyinst = (
            f'"{python}" -m PyInstaller --noconfirm --clean {opts.mode} '
            f'{"--noconsole" if opts.no_console else "--console"} '
            f'--name "{name}_protected" --hidden-import PIL --hidden-import cv2 '
            f'--paths "{obf}" --add-data "{obf}{sep}." "{obf}/{opts.script}"'
        )
        cmd = f'"{python}" -m pyarmor gen -O {obf} "{opts.script}" && {pyinst}'
        return cmd, "Build PyArmor"

    return _pyinstaller_args(opts, python), "Build PyInstaller"


def preview(opts: BuildOptions, source: str = "", python: str = "python") -> str:
    cmd, _ = build_command(opts, source, python)
    if isinstance(cmd, list):
        return " ".join(_quote(a) for a in cmd)
    return cmd


def _quote(arg: str) -> str:
    return f'"{arg}"' if " " in arg else arg
