"""
Persistência de configurações e perfis de build (JSON).

Substitui o esquema key=value do HTA por JSON nativo do Python. Guarda um
config geral (`pyexec_config.json`) e perfis nomeados (`pyexec_profile_<nome>.json`)
no diretório do app.
"""
from __future__ import annotations

import json
from pathlib import Path

CONFIG_NAME = "pyexec_config.json"
PROFILE_PREFIX = "pyexec_profile_"


def _base_dir() -> Path:
    # Diretório do pacote (PyExec_v3/). Mantém os arquivos junto ao app.
    return Path(__file__).resolve().parent.parent.parent


def save_config(data: dict) -> None:
    path = _base_dir() / CONFIG_NAME
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def load_config() -> dict:
    path = _base_dir() / CONFIG_NAME
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return {}


def _safe(name: str) -> str:
    return "".join(c for c in name if c.isalnum() or c in "-_")


def save_profile(name: str, data: dict) -> str:
    safe = _safe(name)
    path = _base_dir() / f"{PROFILE_PREFIX}{safe}.json"
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    return safe


def load_profile(name: str) -> dict | None:
    path = _base_dir() / f"{PROFILE_PREFIX}{_safe(name)}.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (ValueError, OSError):
        return None


def delete_profile(name: str) -> bool:
    path = _base_dir() / f"{PROFILE_PREFIX}{_safe(name)}.json"
    if path.exists():
        path.unlink()
        return True
    return False


def list_profiles() -> list[str]:
    names = []
    for p in _base_dir().glob(f"{PROFILE_PREFIX}*.json"):
        names.append(p.stem[len(PROFILE_PREFIX):])
    return sorted(names)
