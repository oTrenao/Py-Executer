"""Aba BUILDER — PyInstaller / Nuitka, com perfis e preview de comando."""
from __future__ import annotations

import customtkinter as ctk

from .. import theme
from ..core.builder import BuildOptions


class BuildTab(ctk.CTkScrollableFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app
        self.icon_path = ""

        self._build_profiles()
        self._build_output()
        self._build_modules()
        self._build_options()
        self._build_nuitka_advanced()
        self._build_footer()
        self.toggle_nuitka()

    # ----------------------------------------------------------- seções
    def _build_profiles(self):
        sec = _section(self, "💾 Perfis de Build", theme.ACCENT)
        row = ctk.CTkFrame(sec, fg_color="transparent"); row.pack(fill="x", padx=8, pady=6)
        self.profile_menu = ctk.CTkOptionMenu(
            row, values=["— perfis —"], fg_color=theme.BG_INPUT,
            button_color=theme.BG_ELEV, button_hover_color=theme.BORDER, font=theme.FONT_SMALL)
        self.profile_menu.pack(side="left", expand=True, fill="x", padx=(0, 4))
        _btn(row, "📂 Carregar", self.app.load_profile).pack(side="left", padx=2)
        _btn(row, "💾 Salvar", self.app.save_profile).pack(side="left", padx=2)
        _btn(row, "🗑", self.app.delete_profile, width=34, color=theme.RED).pack(side="left", padx=2)

    def _build_output(self):
        sec = _section(self, "✓ Básico: saída e ícone", theme.GREEN_TEXT)
        grid = ctk.CTkFrame(sec, fg_color="transparent"); grid.pack(fill="x", padx=8, pady=6)
        _label(grid, "Formato de saída").pack(anchor="w")
        self.mode = ctk.CTkOptionMenu(
            grid, values=["--onefile", "--onedir", "--accelerated"],
            command=lambda _=None: self.app.validate_mode(),
            fg_color=theme.BG_INPUT, button_color=theme.BG_ELEV,
            button_hover_color=theme.BORDER, font=theme.FONT_SMALL)
        self.mode.pack(fill="x", pady=(0, 8))
        _label(grid, "Ícone do .exe").pack(anchor="w")
        irow = ctk.CTkFrame(grid, fg_color="transparent"); irow.pack(fill="x")
        _btn(irow, "Selecionar ícone (.ico/.png/.jpg)", self.app.pick_icon).pack(
            side="left", expand=True, fill="x")
        self.icon_label = ctk.CTkLabel(grid, text="(nenhum)", font=theme.FONT_SMALL,
                                       text_color=theme.TEXT_MUTED)
        self.icon_label.pack(anchor="w", pady=(2, 0))

    def _build_modules(self):
        sec = _section(self, "➕ Incluir / ✖ Excluir módulos", theme.GREEN_TEXT)
        body = ctk.CTkFrame(sec, fg_color="transparent"); body.pack(fill="x", padx=8, pady=6)
        _label(body, "Collect (PyInstaller) / include-package (Nuitka)").pack(anchor="w")
        r1 = ctk.CTkFrame(body, fg_color="transparent"); r1.pack(fill="x", pady=(0, 6))
        self.collect = _entry(r1, "ex: tkinter pygame cv2"); self.collect.pack(
            side="left", expand=True, fill="x", padx=(0, 4))
        _btn(r1, "🔍 Scan", self.app.scan_collect, width=70).pack(side="left")
        _label(body, "Exclude (reduzir tamanho)").pack(anchor="w")
        r2 = ctk.CTkFrame(body, fg_color="transparent"); r2.pack(fill="x")
        self.exclude = _entry(r2, "ex: unittest matplotlib"); self.exclude.pack(
            side="left", expand=True, fill="x", padx=(0, 4))
        _btn(r2, "🔍 Scan", self.app.scan_exclude, width=70).pack(side="left")

    def _build_options(self):
        sec = _section(self, "⚙ Opções gerais", theme.TEXT_MUTED)
        grid = ctk.CTkFrame(sec, fg_color="transparent"); grid.pack(fill="x", padx=8, pady=6)
        self.no_console = _check(grid, "🚫 Sem console (GUI)", default=True)
        self.nuitka = _check(grid, "⚡ Nuitka (compilar C++)", command=self.toggle_nuitka)
        self.pyarmor = _check(grid, "🔒 PyArmor (ofuscar)")
        self.upx = _check(grid, "📦 UPX (comprimir)")
        self.clean_build = _check(grid, "🧹 Build limpo (venv temp)")
        for w in (self.no_console, self.nuitka, self.pyarmor, self.upx, self.clean_build):
            w.pack(anchor="w", pady=2)

    def _build_nuitka_advanced(self):
        self.nuitka_adv = _section(self, "⚡ Nuitka avançado", theme.ACCENT)
        body = ctk.CTkFrame(self.nuitka_adv, fg_color="transparent"); body.pack(fill="x", padx=8, pady=6)
        _label(body, "Output dir (Nuitka)").pack(anchor="w")
        orow = ctk.CTkFrame(body, fg_color="transparent"); orow.pack(fill="x", pady=(0, 6))
        self.nuitka_out = _entry(orow, "deixe vazio = nome do script"); self.nuitka_out.pack(
            side="left", expand=True, fill="x", padx=(0, 4))
        _btn(orow, "📂", lambda: self.app.pick_into(self.nuitka_out), width=34).pack(side="left")
        self.nuitka_clean_cache = _check(body, "🗑 Limpar cache Nuitka")
        self.nuitka_progress = _check(body, "📊 Mostrar progresso", default=True)
        self.nuitka_memory = _check(body, "🧠 Mostrar memória")
        self.nuitka_msvc = _check(body, "🧰 Usar MSVC (Build Tools)")
        for w in (self.nuitka_clean_cache, self.nuitka_progress, self.nuitka_memory, self.nuitka_msvc):
            w.pack(anchor="w", pady=2)
        _label(body, "LTO").pack(anchor="w", pady=(6, 0))
        self.lto = ctk.CTkOptionMenu(body, values=["--lto=no", "--lto=yes", ""],
                                     fg_color=theme.BG_INPUT, button_color=theme.BG_ELEV,
                                     button_hover_color=theme.BORDER, font=theme.FONT_SMALL)
        self.lto.pack(fill="x", pady=(0, 6))
        _label(body, "Arquivos/pastas de dados (um por linha: origem=destino)").pack(anchor="w")
        self.data_box = ctk.CTkTextbox(body, height=70, fg_color=theme.BG_INPUT,
                                       font=theme.FONT_MONO)
        self.data_box.pack(fill="x", pady=(0, 4))
        drow = ctk.CTkFrame(body, fg_color="transparent"); drow.pack(fill="x")
        _btn(drow, "➕ Arquivo", lambda: self.app.add_data_path(False)).pack(
            side="left", expand=True, fill="x", padx=(0, 4))
        _btn(drow, "➕ Pasta", lambda: self.app.add_data_path(True)).pack(
            side="left", expand=True, fill="x", padx=(0, 4))
        _btn(drow, "🧹 Limpar", lambda: self.data_box.delete("1.0", "end")).pack(side="left")

    def _build_footer(self):
        foot = ctk.CTkFrame(self, fg_color="transparent"); foot.pack(fill="x", pady=(8, 4))
        _btn(foot, "👁 Ver Comando", self.app.preview_build).pack(side="left", padx=(0, 6))
        ctk.CTkButton(foot, text="🔨 COMPILAR EXECUTÁVEL", height=38,
                      font=theme.FONT_UI_BOLD, fg_color=theme.GREEN,
                      hover_color=theme.GREEN_HOVER, command=self.app.build_exe).pack(
            side="left", expand=True, fill="x")

    # ---------------------------------------------------------- helpers
    def toggle_nuitka(self):
        self.nuitka_adv.pack(fill="x", pady=6) if self.nuitka.get() else self.nuitka_adv.pack_forget()

    def set_icon(self, path: str):
        self.icon_path = path
        import os
        self.icon_label.configure(text=os.path.basename(path) if path else "(nenhum)")

    def data_items(self) -> list[str]:
        return [l for l in self.data_box.get("1.0", "end").splitlines() if l.strip()]

    def get_options(self, script: str) -> BuildOptions:
        return BuildOptions(
            script=script, mode=self.mode.get(), no_console=bool(self.no_console.get()),
            use_nuitka=bool(self.nuitka.get()), use_pyarmor=bool(self.pyarmor.get()),
            use_upx=bool(self.upx.get()), clean_build=bool(self.clean_build.get()),
            icon=self.icon_path, collect=self.collect.get(), exclude=self.exclude.get(),
            nuitka_clean_cache=bool(self.nuitka_clean_cache.get()),
            nuitka_show_progress=bool(self.nuitka_progress.get()),
            nuitka_show_memory=bool(self.nuitka_memory.get()),
            nuitka_lto=self.lto.get(), nuitka_msvc=bool(self.nuitka_msvc.get()),
            nuitka_output_dir=self.nuitka_out.get(), data_items=self.data_items(),
        )

    def as_dict(self) -> dict:
        return {
            "mode": self.mode.get(), "no_console": bool(self.no_console.get()),
            "nuitka": bool(self.nuitka.get()), "pyarmor": bool(self.pyarmor.get()),
            "upx": bool(self.upx.get()), "clean_build": bool(self.clean_build.get()),
            "collect": self.collect.get(), "exclude": self.exclude.get(),
            "icon": self.icon_path, "nuitka_clean_cache": bool(self.nuitka_clean_cache.get()),
            "nuitka_progress": bool(self.nuitka_progress.get()),
            "nuitka_memory": bool(self.nuitka_memory.get()), "lto": self.lto.get(),
            "nuitka_msvc": bool(self.nuitka_msvc.get()), "nuitka_out": self.nuitka_out.get(),
            "data": self.data_items(),
        }

    def apply(self, d: dict):
        if not d:
            return
        self.mode.set(d.get("mode", "--onefile"))
        _setck(self.no_console, d.get("no_console", True))
        _setck(self.nuitka, d.get("nuitka", False))
        _setck(self.pyarmor, d.get("pyarmor", False))
        _setck(self.upx, d.get("upx", False))
        _setck(self.clean_build, d.get("clean_build", False))
        _settext(self.collect, d.get("collect", ""))
        _settext(self.exclude, d.get("exclude", ""))
        self.set_icon(d.get("icon", ""))
        _setck(self.nuitka_clean_cache, d.get("nuitka_clean_cache", False))
        _setck(self.nuitka_progress, d.get("nuitka_progress", True))
        _setck(self.nuitka_memory, d.get("nuitka_memory", False))
        self.lto.set(d.get("lto", "--lto=no"))
        _setck(self.nuitka_msvc, d.get("nuitka_msvc", False))
        _settext(self.nuitka_out, d.get("nuitka_out", ""))
        self.data_box.delete("1.0", "end")
        self.data_box.insert("1.0", "\n".join(d.get("data", [])))
        self.toggle_nuitka()


# ----------------------------------------------------------- widget utils
def _section(master, title, color):
    panel = ctk.CTkFrame(master, fg_color=theme.BG_PANEL, border_color=theme.BORDER,
                         border_width=1, corner_radius=theme.RADIUS)
    panel.pack(fill="x", pady=6)
    ctk.CTkLabel(panel, text=title, font=theme.FONT_UI_BOLD, text_color=color).pack(
        anchor="w", padx=10, pady=(6, 0))
    return panel


def _label(master, text):
    return ctk.CTkLabel(master, text=text, font=theme.FONT_SMALL, text_color=theme.TEXT_MUTED)


def _entry(master, placeholder):
    return ctk.CTkEntry(master, placeholder_text=placeholder, font=theme.FONT_SMALL,
                        fg_color=theme.BG_INPUT, border_color=theme.BORDER)


def _btn(master, text, command, width=None, color=theme.BG_ELEV):
    kw = dict(text=text, command=command, font=theme.FONT_SMALL, fg_color=color,
              hover_color=theme.BORDER)
    if width:
        kw["width"] = width
    return ctk.CTkButton(master, **kw)


def _check(master, text, default=False, command=None):
    cb = ctk.CTkCheckBox(master, text=text, font=theme.FONT_SMALL,
                         checkbox_width=18, checkbox_height=18,
                         command=command if command else None)
    if default:
        cb.select()
    return cb


def _setck(cb, value):
    cb.select() if value else cb.deselect()


def _settext(entry, value):
    entry.delete(0, "end")
    entry.insert(0, value or "")
