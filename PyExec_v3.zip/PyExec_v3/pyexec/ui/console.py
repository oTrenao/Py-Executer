"""Console inferior: saída em tempo real + barra de status colorida."""
from __future__ import annotations

import customtkinter as ctk

from .. import theme


class Console(ctk.CTkFrame):
    def __init__(self, master):
        super().__init__(master, fg_color=theme.CONSOLE_BG, corner_radius=0, height=200)
        self.pack_propagate(False)

        header = ctk.CTkFrame(self, fg_color=theme.BG_PANEL, corner_radius=0, height=30)
        header.pack(fill="x")
        header.pack_propagate(False)

        self.status = ctk.CTkLabel(
            header, text="Pronto", text_color=theme.TEXT_MUTED, font=theme.FONT_SMALL
        )
        self.status.pack(side="left", padx=10)

        btns = ctk.CTkFrame(header, fg_color="transparent")
        btns.pack(side="right", padx=6)

        self.btn_save = ctk.CTkButton(
            btns, text="💾 Salvar Log", width=90, height=22, font=theme.FONT_SMALL,
            fg_color=theme.BG_ELEV, hover_color=theme.BORDER,
        )
        self.btn_save.pack(side="left", padx=3)
        self.btn_clear = ctk.CTkButton(
            btns, text="Limpar", width=60, height=22, font=theme.FONT_SMALL,
            fg_color=theme.BG_ELEV, hover_color=theme.BORDER, command=self.clear,
        )
        self.btn_clear.pack(side="left", padx=3)
        self.btn_stop = ctk.CTkButton(
            btns, text="⛔ PARAR", width=80, height=22, font=theme.FONT_SMALL,
            fg_color=theme.RED, hover_color=theme.RED_HOVER, state="disabled",
        )
        self.btn_stop.pack(side="left", padx=3)

        self.text = ctk.CTkTextbox(
            self, fg_color=theme.CONSOLE_BG, text_color=theme.CONSOLE_FG,
            font=theme.FONT_MONO, wrap="word", corner_radius=0,
        )
        self.text.pack(fill="both", expand=True)

    # --- API pública ---
    def write(self, line: str) -> None:
        self.text.insert("end", line + "\n")
        self.text.see("end")

    def clear(self) -> None:
        self.text.delete("1.0", "end")

    def get_text(self) -> str:
        return self.text.get("1.0", "end")

    def set_status(self, text: str, color: str = theme.TEXT_MUTED) -> None:
        self.status.configure(text=text, text_color=color)

    def set_running(self, running: bool) -> None:
        self.btn_stop.configure(state="normal" if running else "disabled")
