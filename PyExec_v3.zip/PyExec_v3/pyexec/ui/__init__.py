"""Camada de interface (CustomTkinter)."""
