"""Aba EXECUTAR — primeira aba portada para CustomTkinter."""
from __future__ import annotations

import customtkinter as ctk

from .. import theme


class RunTab(ctk.CTkFrame):
    """Recebe `app` para disparar ações (rodar, verificar deps)."""

    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app

        # --- Painel: Controles de Execução ---
        exec_panel = _panel(self, "Controles de Execução")
        body = ctk.CTkFrame(exec_panel, fg_color="transparent")
        body.pack(fill="x", padx=10, pady=8)

        self.interactive = ctk.CTkCheckBox(
            body, text="Modo Interativo (janela externa)", font=theme.FONT_SMALL,
            checkbox_width=18, checkbox_height=18,
        )
        self.interactive.pack(anchor="w", pady=(0, 8))

        self.btn_run = ctk.CTkButton(
            body, text="▶  RODAR SCRIPT", height=40, font=theme.FONT_UI_BOLD,
            fg_color=theme.GREEN, hover_color=theme.GREEN_HOVER,
            command=self.app.run_script,
        )
        self.btn_run.pack(fill="x")

        # --- Painel: Dependências ---
        dep_panel = _panel(self, "Dependências")
        dbody = ctk.CTkFrame(dep_panel, fg_color="transparent")
        dbody.pack(fill="x", padx=10, pady=8)

        row = ctk.CTkFrame(dbody, fg_color="transparent")
        row.pack(fill="x")
        ctk.CTkButton(
            row, text="🔍 Verificar", font=theme.FONT_SMALL,
            fg_color=theme.BG_ELEV, hover_color=theme.BORDER,
            command=self.app.check_dependencies,
        ).pack(side="left", expand=True, fill="x", padx=(0, 4))
        ctk.CTkButton(
            row, text="⬇ Instalar Faltantes", font=theme.FONT_SMALL,
            fg_color=theme.BLUE, hover_color=theme.ACCENT,
            command=self.app.install_missing,
        ).pack(side="left", expand=True, fill="x", padx=(4, 0))

        ctk.CTkLabel(
            dbody, text="Análise via AST do arquivo selecionado (sem falsos positivos).",
            font=theme.FONT_SMALL, text_color=theme.TEXT_MUTED, wraplength=520, justify="left",
        ).pack(anchor="w", pady=(8, 0))


def _panel(master, title: str) -> ctk.CTkFrame:
    """Cria um cartão com cabeçalho no estilo do app e devolve o corpo."""
    panel = ctk.CTkFrame(master, fg_color=theme.BG_PANEL, border_color=theme.BORDER,
                         border_width=1, corner_radius=theme.RADIUS)
    panel.pack(fill="x", pady=6)
    head = ctk.CTkFrame(panel, fg_color=theme.BG_ELEV, corner_radius=0, height=26)
    head.pack(fill="x")
    head.pack_propagate(False)
    ctk.CTkLabel(head, text=title.upper(), font=theme.FONT_SMALL,
                 text_color=theme.TEXT_MUTED).pack(side="left", padx=10)
    return panel
