"""Aba SISTEMA — manutenção, configuração e sobre."""
from __future__ import annotations

import customtkinter as ctk

from .. import APP_NAME, __version__, theme


class SystemTab(ctk.CTkScrollableFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app

        m = _panel(self, "Manutenção")
        body = ctk.CTkFrame(m, fg_color="transparent"); body.pack(fill="x", padx=10, pady=8)
        ctk.CTkButton(body, text="🧹 Limpar Lixo de Build", fg_color=theme.RED,
                      hover_color=theme.RED_HOVER, command=app.clean_cache).pack(fill="x")
        row = ctk.CTkFrame(body, fg_color="transparent"); row.pack(fill="x", pady=(6, 0))
        ctk.CTkButton(row, text="💾 Salvar Configuração", font=theme.FONT_SMALL,
                      fg_color=theme.BG_ELEV, hover_color=theme.BORDER,
                      command=app.save_config_now).pack(side="left", expand=True, fill="x", padx=(0, 4))
        ctk.CTkButton(row, text="📥 Exportar Log", font=theme.FONT_SMALL,
                      fg_color=theme.BG_ELEV, hover_color=theme.BORDER,
                      command=app.save_log).pack(side="left", expand=True, fill="x")

        ctk.CTkLabel(body, text="PIP MANUAL", font=theme.FONT_SMALL,
                     text_color=theme.TEXT_MUTED).pack(anchor="w", pady=(8, 0))
        prow = ctk.CTkFrame(body, fg_color="transparent"); prow.pack(fill="x")
        self.manual_pip = ctk.CTkEntry(prow, placeholder_text="lib...", font=theme.FONT_SMALL,
                                       fg_color=theme.BG_INPUT, border_color=theme.BORDER)
        self.manual_pip.pack(side="left", expand=True, fill="x", padx=(0, 4))
        ctk.CTkButton(prow, text="Install", width=70, font=theme.FONT_SMALL,
                      fg_color=theme.BG_ELEV, hover_color=theme.BORDER,
                      command=lambda: app.manual_pip_install(self.manual_pip.get())).pack(side="left")
        ctk.CTkLabel(body, text="As opções de build são salvas ao fechar e restauradas ao abrir.",
                     font=theme.FONT_SMALL, text_color=theme.TEXT_MUTED, wraplength=520,
                     justify="left").pack(anchor="w", pady=(8, 0))

        a = _panel(self, "Sobre")
        ctk.CTkLabel(
            a, justify="center", font=theme.FONT_SMALL, text_color=theme.TEXT_MUTED,
            text=(f"{APP_NAME}  ·  v{__version__}\n"
                  "Núcleo reescrito em Python + CustomTkinter\n"
                  "Streaming real · stop por PID · imports via AST\n"
                  "Builder PyInstaller/Nuitka · perfis · qualidade de código"),
        ).pack(padx=10, pady=10)


def _panel(master, title):
    p = ctk.CTkFrame(master, fg_color=theme.BG_PANEL, border_color=theme.BORDER,
                     border_width=1, corner_radius=theme.RADIUS)
    p.pack(fill="x", pady=6)
    head = ctk.CTkFrame(p, fg_color=theme.BG_ELEV, corner_radius=0, height=26)
    head.pack(fill="x"); head.pack_propagate(False)
    ctk.CTkLabel(head, text=title.upper(), font=theme.FONT_SMALL,
                 text_color=theme.TEXT_MUTED).pack(side="left", padx=10)
    return p
