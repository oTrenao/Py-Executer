"""Aba TOOLS — qualidade de código e gerenciamento de dependências."""
from __future__ import annotations

import customtkinter as ctk

from .. import theme


class ToolsTab(ctk.CTkScrollableFrame):
    def __init__(self, master, app):
        super().__init__(master, fg_color="transparent")
        self.app = app

        # --- Qualidade de código ---
        q = _panel(self, "Qualidade de Código")
        ctk.CTkButton(q, text="⬇ Instalar Kit Dev", fg_color=theme.BLUE,
                      hover_color=theme.ACCENT, command=app.install_kit).pack(
            fill="x", padx=10, pady=(8, 4))
        grid = ctk.CTkFrame(q, fg_color="transparent"); grid.pack(fill="x", padx=10, pady=(0, 8))
        tools = [
            ("🔍 Pylint", ["pylint"], True), ("⚡ Ruff", ["ruff", "check"], True),
            ("🎨 Black", ["black"], True), ("🏷 Mypy", ["mypy"], True),
            ("🔒 Bandit", ["bandit", "-r"], True), ("🛡 Pip-Audit", ["pip_audit"], False),
            ("🧪 Pytest", ["pytest"], False), ("📜 Pip Freeze", ["pip", "freeze"], False),
        ]
        for i, (label, args, needs_file) in enumerate(tools):
            ctk.CTkButton(grid, text=label, font=theme.FONT_SMALL, fg_color=theme.BG_ELEV,
                          hover_color=theme.BORDER,
                          command=lambda a=args, n=needs_file: app.run_tool(a, n)).grid(
                row=i // 2, column=i % 2, sticky="ew", padx=3, pady=3)
        grid.columnconfigure((0, 1), weight=1)

        # --- Requirements & dependências ---
        d = _panel(self, "Requirements & Dependências")
        dg = ctk.CTkFrame(d, fg_color="transparent"); dg.pack(fill="x", padx=10, pady=8)
        reqs = [
            ("📄 requirements (scan)", app.gen_requirements_scan),
            ("🧊 requirements (freeze)", app.gen_requirements_freeze),
            ("⬆ Ver desatualizadas", app.check_outdated),
            ("🔄 Atualizar todas", app.update_all_outdated),
        ]
        for i, (label, cmd) in enumerate(reqs):
            ctk.CTkButton(dg, text=label, font=theme.FONT_SMALL, fg_color=theme.BG_ELEV,
                          hover_color=theme.BORDER, command=cmd).grid(
                row=i // 2, column=i % 2, sticky="ew", padx=3, pady=3)
        dg.columnconfigure((0, 1), weight=1)
        ctk.CTkLabel(d, text="'scan' = só as libs importadas. 'freeze' = todo o ambiente.",
                     font=theme.FONT_SMALL, text_color=theme.TEXT_MUTED).pack(
            anchor="w", padx=10, pady=(0, 8))


def _panel(master, title):
    p = ctk.CTkFrame(master, fg_color=theme.BG_PANEL, border_color=theme.BORDER,
                     border_width=1, corner_radius=theme.RADIUS)
    p.pack(fill="x", pady=6)
    head = ctk.CTkFrame(p, fg_color=theme.BG_ELEV, corner_radius=0, height=26)
    head.pack(fill="x"); head.pack_propagate(False)
    ctk.CTkLabel(head, text=title.upper(), font=theme.FONT_SMALL,
                 text_color=theme.TEXT_MUTED).pack(side="left", padx=10)
    return p
