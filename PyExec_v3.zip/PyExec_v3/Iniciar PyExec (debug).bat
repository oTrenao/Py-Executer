@echo off
title Py Executer Ultimate v3.0 - DEBUG
cd /d "%~dp0"
REM Abre com console visivel para ver erros (modo depuracao).

if exist ".appenv\Scripts\python.exe" (
    call ".appenv\Scripts\python.exe" main.py
) else (
    where py >nul 2>&1 && ( py -3 main.py ) || ( python main.py )
)

echo.
echo --- O aplicativo foi fechado. ---
pause
